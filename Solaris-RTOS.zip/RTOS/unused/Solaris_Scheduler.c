#include "Solaris_Scheduler.h"

tcb_t TCBS[6];
//Created tasks is number of total tasks
uint8_t createdTasks;
//Numtasks is number of active tasks
uint8_t numTasks;
uint8_t currTask;
uint8_t next_task;
Node_t *schedule_array[6];

																							//UNFINISHED FUNCTION
void rtosDelay(int num_timeslices)
{
	//Blocks current task, current task node is already removed from linked list array so just need to update its
	//status, and the next PendSV_Handler will handle everything
	
	TCBS[currTask].status = task_blocked;
	TCBS[currTask].timeslices_to_be_blocked = num_timeslices;
	TCBS[currTask].timeslices_since_blocked = 0;
}

//Gets called in task initialization and pre-emting
void add_node(uint8_t priority_, uint8_t taskNum)
{
	//Iterate down linked list
	Node_t* currNode = schedule_array[priority_];

	//Case 1: if this priority's linked list is empty, just insert)
	if (schedule_array[priority_] == NULL)
	{
    Node_t* newNode = (Node_t*)malloc(sizeof(Node_t));
    (*newNode).task_num = taskNum;
    (*newNode).next = NULL;

		schedule_array[priority_] = newNode;
	}
	//Case 2: if not empty
  else
  {
    while ((*currNode).next != NULL)
    {
      currNode = (*currNode).next;
    }
    //Now at last node
    
    //Set last node pointer to pointer of new node, and set its members
    Node_t* newNode = (Node_t*)malloc(sizeof(Node_t));
    (*newNode).task_num = taskNum;
    (*newNode).next = NULL;

    (*currNode).next = newNode;
  }
}

//Returns task number of task removed, 0 if no ready tasks at priority, 
//-1 if invalid priority
uint8_t remove_front_node(uint8_t priority)
{
  uint8_t taskNumOfRemoved = 0;

  if (priority > 5)
    return 99;

  if (schedule_array[priority] == NULL)
    return 0;
    
  taskNumOfRemoved = (*schedule_array[priority]).task_num;

  Node_t* secondNode = (*schedule_array[priority]).next;
  free(schedule_array[priority]);
  schedule_array[priority] = secondNode;

  numTasks--;

  return (uint8_t)taskNumOfRemoved;
}

void task_create(rtosTaskFunc_t taskFunction, void *R0, uint8_t priority_)
{
	//Protects against more than 6 tasks being created
	if (numTasks > 5)
		return;
	
	add_node(priority_, numTasks);
		
	//Initialize TCB members
	TCBS[numTasks].stack_pointer = TCBS[numTasks].base - 15;
	TCBS[numTasks].priority = priority_;
	TCBS[numTasks].status = task_ready;
	TCBS[numTasks].timeslices_since_blocked = 0;
	TCBS[numTasks].timeslices_to_be_blocked = 0;
	
	//Setting R0
	*(TCBS[numTasks].base - 7) = (uint32_t)R0;
	//Setting task function address
	*(TCBS[numTasks].base - 1) = (uint32_t)(*taskFunction);
	//Setting P0 to default value of 0x01000000 as specified in manual
	*(TCBS[numTasks].base) = (uint32_t)(0x01000000);

  numTasks++;
	createdTasks++;
}

//Return -1 if no available next task
uint8_t find_next_task()
{
	
  //Iterate down bit vector until find next available priority
  int next_priority = 5;
  while (schedule_array[next_priority] == NULL && next_priority >= 0) {
    next_priority--;
  }
  
  //If no available next task
  if (next_priority == -1)
	{
		printf("No available next task, ERROR");
    return 99;
	}

  //If available next task, return first task num of linked list.
  //Because available tasks are added at back of linked list
  //and ready tasks are removed at front of linked list,
  //tasks of equal priority that are ready are round robined
  return (uint8_t)(*schedule_array[next_priority]).task_num;
}

void initialization(void) 
{
	// Initialize TCB base address for its stack
	
	// Find address of main stack (first 32 bit value at 0x0 is base address)
	// Then go up for tcbs 54321 but substract instead (subtract by 2 kib, then 1 kib (800, then 400)
	uint32_t **mainstack = 0x0;
	//This used to copy over main stack to task 1 stack
	uint32_t *mainstack_address = *mainstack;
	//This used to remember where main stack base is
	uint32_t *mainstack_base = *mainstack;
	
	TCBS[5].base = (uint32_t *)(mainstack_address - 0x0800/4);
	TCBS[4].base = (uint32_t *)(mainstack_address - 0x1200/4);
	TCBS[3].base = (uint32_t *)(mainstack_address - 0x1600/4);
	TCBS[2].base = (uint32_t *)(mainstack_address - 0x2000/4);
	TCBS[1].base = (uint32_t *)(mainstack_address - 0x2400/4);
	TCBS[0].base = (uint32_t *)(mainstack_address - 0x2800/4);
	
	numTasks = 0;
	
	//Initialize schedule array to all point to NULL. Will be populated by task create function.
	for (int i=0; i<6; i++)
		schedule_array[i] = NULL;
	
	// Copy the main stack contents to process stack of new main() task and set the MSP to the main stack base address
	// Loop through each item and then save to next stack from mainstack_address - 0x8000
	
	uint32_t *MSP = (uint32_t *)__get_MSP();
	TCBS[0].current = TCBS[0].base;
	
	//Copy everything in main stack to task 1 stack
	while (mainstack_address >= MSP) {
		*TCBS[0].current = *mainstack_address;
		TCBS[0].current--;
		
		mainstack_address--;
		
	}
	
	TCBS[0].stack_pointer = TCBS[0].current + 1;
	
	//Set MSP to mainstack base address
	__set_MSP((uint32_t)mainstack_base);
	
	//Switches control from MSP to PSP
	__set_CONTROL(__get_CONTROL() | (1 << 1));
	
	//Set PSP to top of task 1 stack
	// TCB1.current may have decremented 1 too much
	__set_PSP((uint32_t)TCBS[0].stack_pointer);
	
	//Begin multithread by running task 0. Correct next task will be 
	//determined at next pre-empt in PendSV_Handler
	currTask = 0;
	
	//Set task 1 priority to 0, acts as idle task
	TCBS[0].priority = 0;
	
	//Set task 1 status to ready
	TCBS[0].status = task_ready;
	TCBS[0].timeslices_since_blocked = 0;
	TCBS[0].timeslices_to_be_blocked = 0;
	
	//Increment numtasks now that there is a task
	numTasks++;
	createdTasks++;
}