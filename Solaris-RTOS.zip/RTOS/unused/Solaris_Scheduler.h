#ifndef solaris_scheduler_
#define solaris_scheduler_

#include <LPC17xx.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

uint32_t msTicks = 0;

// Define task status macros
typedef uint8_t task_status;
#define task_ready		1
#define task_blocked	0

// Declare TCB 
typedef struct{
	//Bottom of task stack (highest address)
  uint32_t *base;
	//Temp pointer
	uint32_t *current;
	//Top of stack, could also be on top of pushed registers (lowest address)
	uint32_t *stack_pointer;
	
	uint8_t priority;
	task_status status;
	
	//Total number of timeslices to be blocked, >1 if rtosDelay called, 1 if rtosYield or rtosDelay(0) is called
	uint32_t timeslices_to_be_blocked;
	//Timeslices that have been blocked so far. Incremented in PendSV_Handler, and if >timeslices_to_be_blocked, task is blocked->activated
	uint32_t timeslices_since_blocked;
}tcb_t;

//Node datatype
typedef struct Node_t{
	uint8_t task_num;
	struct Node_t *next;
}Node_t;

//Function pointer to create task function
typedef void(*rtosTaskFunc_t)(void *args);

																												//UNFINISHED FUNCTION
void rtosDelay(int num_timeslices);

//Gets called in task initialization and pre-emting
void add_node(uint8_t priority_, uint8_t taskNum);

void task_create(rtosTaskFunc_t taskFunction, void *R0, uint8_t priority_);

uint8_t remove_front_node(uint8_t priority);

//Return -1 if no available next task
uint8_t find_next_task();

void initialization(void);

#endif