#ifndef solaris_mutex_
#define solaris_mutex_

#include <stdbool.h>
#include <stdint.h>

enum mutex_state
{
	ACQUIRED,
	RELEASED
};

//Mutex datatype
typedef struct mutex
{
	//Max 50 character string for mutex ID
	char id[50];
	//ACQUIRED = 0, RELEASED = 1
	bool state;
	//Which task acquired
	uint8_t acquiredTask;
}mutex;

typedef enum
{
	timeout,
	acquired,
	nonexistent
}acquireStatus;

//Mutex acquire
//acquireStatus acquireMutex(char* 

#endif