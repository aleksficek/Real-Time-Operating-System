#include "main_default.c"

void first_task(void *args) {
	while (1)
	{
		wait(&lock1);
		printf("=========================================FIRST TASK IS NOW RUNNING===============================================\n");
		mutex_acquire(&mutex_lock);
		for (uint32_t i=0; i<1000; i++)
		{
			printf("%d", currTask);
			if (!(i%100))
				printf("\n");
		}
		mutex_release(&mutex_lock);
		signal(&lock1);
	}
}

void second_task(void *args) {
	while (1)
	{
		mutex_acquire(&mutex_lock);
		printf("======================================TASK 2: I HAVE ACQUIRED THE MUTEX======================================\n");
		signal(&lock1);
		for (uint32_t i=0; i<1000; i++)
		{
			printf("%d", currTask);
			if (!(i%100))
				printf("\n");
		}
		printf("======================================TASK 2: I HAVE RELEASED THE MUTEX======================================\n");
		mutex_release(&mutex_lock);
	}
}

int main(void) {
	printf("\n   _____  ____  _               _____  _____  _____   _____ _______ ____   _____ \n");
	printf("  / ____|/ __ \| |        /\   |  __ \|_   _|/ ____| |  __ \__   __/ __ \ / ____|\n");
	printf(" | (___ | |  | | |       /  \  | |__) | | | | (___   | |__) | | | | |  | | (___  \n");
	printf("  \___ \| |  | | |      / /\ \ |  _  /  | |  \___ \  |  _  /  | | | |  | |\___ \ \n");
	printf("  ____) | |__| | |____ / ____ \| | \ \ _| |_ ____) | | | \ \  | | | |__| |____) |\n");
	printf(" |_____/ \____/|______/_/    \_\_|  \_\_____|_____/  |_|  \_\ |_|  \____/|_____/ \n");

	//Initialization creates task 0
	initialization();
	
	mutex_init(&mutex_lock, 1);
	semaphore_init(&lock1, 0);
	
	rtosTaskFunc_t task1 = &first_task;
	task_create(task1, NULL, 5);
	rtosTaskFunc_t task2 = &second_task;
	task_create(task2, NULL, 1);
 
	SysTick_Config(SystemCoreClock/(1000));
	
	while(true) {
		printf("\n\n=========================================TASK 0, IDLE TASK====================================\n\n");
		for (int priority = 0; priority<6; priority++)
		{
			Node_t *currNode = schedule_array[priority];
			printf("\t\t\t\tPriority list %d:", priority);
			
			while (currNode != NULL)
			{
				printf("%d ", (*currNode).task_num);
				currNode = (*currNode).next;
			}
			printf("\n");
		}
		printf("\n");
	}
}